
function Footer(){
    return <div>
        <h4>Made by Iwaddi</h4>
    </div>
}

export default Footer